interface PaymentToken {
    id: string
    decimals: number
    symbol: string
}
interface Collection {
    id: string
    name: string
    symbol: string
}
interface Target {
    id: string
    tokenId: string
    tokenURI: string
    collection: Collection
}
interface metadata {
    image:string
    name:string
    author: string
    totalSupply: string
    description: string
    imageFull: string
    animationType: string
    animation_url: string
}
interface Iliquidity {
    priceDollar: string
    hasLiquidity: boolean
}
export interface Erc721Attribute {

}

export interface Erc721Properties {

}
