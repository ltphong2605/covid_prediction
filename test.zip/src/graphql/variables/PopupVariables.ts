import { makeVar } from '@apollo/client'

export const popupModalVar = makeVar(false)
export const popupModalRedirectVar = makeVar('')
