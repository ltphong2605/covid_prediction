import { makeVar } from '@apollo/client'

export const metadataTabAuctionVar = makeVar<'details' | 'fraction'>('details')
